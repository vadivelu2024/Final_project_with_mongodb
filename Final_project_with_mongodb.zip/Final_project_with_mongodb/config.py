# Database configuration
MONGODB_URI = 'mongodb://localhost:27017/'
MONGODB_DB = 'parkeasy_db'
